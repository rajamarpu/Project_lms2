// One-off dev utility: bulk-approves every existing user and course.
// This is a destructive, irreversible bulk update -- it intentionally
// refuses to run against production and reads its connection from the
// shared, environment-based Prisma client instead of a hardcoded URL.
require('dotenv').config();
const { prisma } = require('./src/config/db');

async function approveExisting() {
  if (process.env.NODE_ENV === 'production') {
    console.error('Refusing to run approveExisting.js with NODE_ENV=production. This is a dev-only utility.');
    process.exit(1);
  }

  try {
    const users = await prisma.user.updateMany({ data: { status: 'approved' } });
    const courses = await prisma.course.updateMany({ data: { status: 'approved' } });
    console.log(`Approved ${users.count} user(s) and ${courses.count} course(s).`);
  } catch (err) {
    console.error(err);
  } finally {
    await prisma.$disconnect();
  }
}

approveExisting();
