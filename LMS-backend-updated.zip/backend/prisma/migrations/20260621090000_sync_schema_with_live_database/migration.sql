-- Sync migration: brings migration history in line with the schema that is
-- already live (it was previously applied with `prisma db push` instead of
-- `prisma migrate dev`, so these columns/tables existed in the database but
-- had no corresponding migration file).
--
-- This migration is purely additive:
--   - All new columns are nullable OR carry a safe default, so it does not
--     fail or change values on existing rows.
--   - No columns are dropped, renamed, or have their type changed.
--   - No existing data is deleted.

-- AlterTable: User (status / bio / avatar were already in use by the app)
ALTER TABLE "User" ADD COLUMN     "status" TEXT NOT NULL DEFAULT 'pending',
ADD COLUMN     "bio" TEXT,
ADD COLUMN     "avatar" TEXT;

-- AlterTable: Course (already in use by courses.controller.js and seed.js)
ALTER TABLE "Course" ADD COLUMN     "price" DOUBLE PRECISION NOT NULL DEFAULT 0,
ADD COLUMN     "duration" TEXT,
ADD COLUMN     "rating" DOUBLE PRECISION NOT NULL DEFAULT 4.5,
ADD COLUMN     "outcomes" TEXT[] NOT NULL DEFAULT ARRAY[]::TEXT[],
ADD COLUMN     "xp" TEXT,
ADD COLUMN     "gradient" TEXT,
ADD COLUMN     "icon" TEXT,
ADD COLUMN     "status" TEXT NOT NULL DEFAULT 'pending';

-- AlterTable: Enrollment (certificate workflow fields already in use by admin.controller.js)
ALTER TABLE "Enrollment" ADD COLUMN     "certificateApproved" BOOLEAN NOT NULL DEFAULT false,
ADD COLUMN     "mentor" TEXT;

-- CreateTable: LearningPath (already used by seed.js and courses.controller.js)
CREATE TABLE "LearningPath" (
    "id" TEXT NOT NULL,
    "slug" TEXT NOT NULL,
    "title" TEXT NOT NULL,
    "description" TEXT NOT NULL,
    "duration" TEXT NOT NULL,
    "color" TEXT NOT NULL DEFAULT 'teal',
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "LearningPath_pkey" PRIMARY KEY ("id")
);

-- CreateTable: implicit many-to-many join table for Course <-> LearningPath
CREATE TABLE "_LearningPathCourses" (
    "A" TEXT NOT NULL,
    "B" TEXT NOT NULL,

    CONSTRAINT "_LearningPathCourses_AB_pkey" PRIMARY KEY ("A","B")
);

-- CreateIndex
CREATE UNIQUE INDEX "LearningPath_slug_key" ON "LearningPath"("slug");

-- CreateIndex
CREATE INDEX "_LearningPathCourses_B_index" ON "_LearningPathCourses"("B");

-- AddForeignKey
ALTER TABLE "_LearningPathCourses" ADD CONSTRAINT "_LearningPathCourses_A_fkey" FOREIGN KEY ("A") REFERENCES "Course"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "_LearningPathCourses" ADD CONSTRAINT "_LearningPathCourses_B_fkey" FOREIGN KEY ("B") REFERENCES "LearningPath"("id") ON DELETE CASCADE ON UPDATE CASCADE;
