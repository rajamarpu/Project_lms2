-- Schema integrity improvements (deliberate, reviewed changes):
--
-- 1. User.status and Course.status become real enums instead of free-text
--    strings, so the database itself rejects an invalid status value.
--    The enum variants match the exact strings already written by the app
--    (see auth.controller.js, admin.controller.js, courses.controller.js),
--    so this is a type change only -- no values are altered.
--
-- 2. Course.instructorId foreign key changes from ON DELETE CASCADE to
--    ON DELETE RESTRICT. Today, deleting an instructor's User row silently
--    cascades and deletes every course they created -- and, transitively,
--    every lesson and every student enrollment/progress record tied to
--    those courses. RESTRICT stops that delete from happening until courses
--    are reassigned or explicitly removed first, which matches "use cascade
--    delete only where child data should never exist without a parent"
--    (a Course can exist without that exact instructor; a student's
--    Enrollment cannot exist without the Course, so that cascade is kept).
--
-- 3. Indexes are added on foreign key columns that are filtered on directly
--    in application code (instructor stats, lesson lookups, enrollment
--    lookups) but had no index, including the dedicated Enrollment.courseId
--    index needed for the case where you only have a courseId.

-- CreateEnum
CREATE TYPE "UserStatus" AS ENUM ('pending', 'approved', 'rejected', 'suspended');

-- CreateEnum
CREATE TYPE "CourseStatus" AS ENUM ('pending', 'approved', 'rejected');

-- AlterTable: User.status TEXT -> UserStatus
ALTER TABLE "User" ALTER COLUMN "status" DROP DEFAULT;
ALTER TABLE "User" ALTER COLUMN "status" TYPE "UserStatus" USING ("status"::"UserStatus");
ALTER TABLE "User" ALTER COLUMN "status" SET DEFAULT 'pending';

-- AlterTable: Course.status TEXT -> CourseStatus
ALTER TABLE "Course" ALTER COLUMN "status" DROP DEFAULT;
ALTER TABLE "Course" ALTER COLUMN "status" TYPE "CourseStatus" USING ("status"::"CourseStatus");
ALTER TABLE "Course" ALTER COLUMN "status" SET DEFAULT 'pending';

-- DropForeignKey
ALTER TABLE "Course" DROP CONSTRAINT "Course_instructorId_fkey";

-- AddForeignKey: Cascade -> Restrict (see note above)
ALTER TABLE "Course" ADD CONSTRAINT "Course_instructorId_fkey" FOREIGN KEY ("instructorId") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- CreateIndex
CREATE INDEX "Course_instructorId_idx" ON "Course"("instructorId");

-- CreateIndex
CREATE INDEX "Lesson_courseId_idx" ON "Lesson"("courseId");

-- CreateIndex
CREATE INDEX "Enrollment_userId_idx" ON "Enrollment"("userId");

-- CreateIndex
CREATE INDEX "Enrollment_courseId_idx" ON "Enrollment"("courseId");
