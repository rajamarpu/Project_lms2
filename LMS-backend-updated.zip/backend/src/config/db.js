require('dotenv').config();
const { PrismaClient } = require('@prisma/client');
const { PrismaPg } = require('@prisma/adapter-pg');
const { readReplicas } = require('@prisma/extension-read-replicas');
const logger = require('../utils/logger');
const { validateEnv } = require('./validateEnv');

// Fail fast with a clear message if required DB/auth env vars are missing,
// rather than letting a confusing connection error surface later.
validateEnv();

const adapter = new PrismaPg({ connectionString: process.env.DATABASE_URL });

// Full query logging (including bound parameter values) is invaluable in
// development but can leak sensitive data (emails, tokens, etc.) into log
// output in production. Keep it verbose locally, quieter in production.
const isProduction = process.env.NODE_ENV === 'production';
const prismaLogLevels = isProduction ? ['warn', 'error'] : ['query', 'info', 'warn', 'error'];

// Base prisma client
const basePrisma = new PrismaClient({ 
  adapter,
  log: prismaLogLevels,
});

// Extend prisma client with read replicas ONLY if a replica URL is provided
const prisma = process.env.DATABASE_URL_REPLICA 
  ? basePrisma.$extends(
      readReplicas({
        url: process.env.DATABASE_URL_REPLICA,
      })
    )
  : basePrisma;

const connectDB = async () => {
  try {
    await basePrisma.$connect();
    logger.info('PostgreSQL Primary Connected via Prisma');
    // Read replicas are connected on-demand by the extension, but we log readiness
    logger.info(`Database Read-Replica Ready: ${!!process.env.DATABASE_URL_REPLICA}`);
  } catch (error) {
    logger.error({ err: error }, 'Database connection error');
    logger.error(
      'If this is a Supabase direct connection that fails to resolve or ' +
      'time out, try the Session pooler connection string instead (copy it ' +
      'from Project Settings -> Database -> Connection string -> Session ' +
      'pooler) -- see .env.example for the exact format.'
    );
    process.exit(1);
  }
};

module.exports = { connectDB, prisma };
