/**
 * Fails fast and loudly if required environment variables are missing or
 * obviously malformed, instead of letting the app boot and crash later with
 * a confusing Postgres/JWT error several requests in.
 *
 * Required for every environment (local, test, production):
 *   - DATABASE_URL
 *   - JWT_SECRET
 *
 * This intentionally does NOT validate DATABASE_URL_REPLICA, REDIS_HOST,
 * REDIS_PORT, or GEMINI_API_KEY here because those features are designed to
 * degrade gracefully when absent (see db.js and redis.service.js).
 */

const logger = require('../utils/logger');

const REQUIRED_VARS = ['DATABASE_URL', 'JWT_SECRET'];

function validateEnv() {
  const missing = REQUIRED_VARS.filter((key) => !process.env[key] || process.env[key].trim() === '');

  if (missing.length > 0) {
    logger.error(
      `Missing required environment variable(s): ${missing.join(', ')}. ` +
      'Copy .env.example to .env and fill these in before starting the server.'
    );
    process.exit(1);
  }

  const dbUrl = process.env.DATABASE_URL;
  if (!/^postgres(ql)?:\/\//.test(dbUrl)) {
    logger.error(
      'DATABASE_URL does not look like a valid PostgreSQL connection string ' +
      '(expected it to start with "postgresql://" or "postgres://"). ' +
      'Check .env against .env.example.'
    );
    process.exit(1);
  }

  // Supabase-specific guidance: a direct connection host (db.<project-ref>.supabase.co)
  // can fail to resolve/connect from some networks and from most serverless or
  // IPv6-only hosts. If that happens, switch to the Supabase Session pooler
  // host (postgres.<project-ref>@aws-<n>-<region>.pooler.supabase.com, still
  // port 5432) with ?sslmode=require&uselibpqcompat=true. See .env.example.
  if (dbUrl.includes('supabase.co') && !dbUrl.includes('pooler')) {
    logger.warn(
      'DATABASE_URL is using a direct Supabase connection. ' +
      'If the app fails to connect (common on serverless/IPv6-restricted networks), ' +
      'switch to the Supabase Session pooler URL from Project Settings -> Database -- see .env.example.'
    );
  }
}

module.exports = { validateEnv };
