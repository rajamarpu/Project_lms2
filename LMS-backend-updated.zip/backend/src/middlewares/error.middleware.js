const ErrorResponse = require('../utils/errorResponse');

const logger = require('../utils/logger');

const errorHandler = (err, req, res, next) => {
  let error = { ...err };
  error.message = err.message;
  error.statusCode = err.statusCode;
  error.name = err.name;

  // Log with pino
  logger.error(err);

  // Prisma unique constraint violation
  if (err.code === 'P2002') {
    const message = 'Duplicate field value entered';
    error = new ErrorResponse(message, 400);
  }

  // Prisma record not found
  if (err.code === 'P2025') {
    const message = 'Record not found';
    error = new ErrorResponse(message, 404);
  }

  // Prisma foreign key constraint violation (e.g. deleting an instructor who
  // still has courses, now blocked by ON DELETE RESTRICT instead of silently
  // cascading and losing the courses/lessons/enrollments underneath them)
  if (err.code === 'P2003') {
    const message = 'Cannot complete this action because related records still reference it. Remove or reassign those records first.';
    error = new ErrorResponse(message, 409);
  }

  // Zod Validation Error
  if (err.name === 'ZodError') {
    const message = err.errors.map(val => val.message).join(', ');
    error = new ErrorResponse(message, 400);
  }

  // JWT Errors
  if (err.name === 'JsonWebTokenError') {
    const message = 'Invalid token. Please log in again.';
    error = new ErrorResponse(message, 401);
  }

  if (err.name === 'TokenExpiredError') {
    const message = 'Your token has expired. Please log in again.';
    error = new ErrorResponse(message, 401);
  }

  res.status(error.statusCode || 500).json({
    success: false,
    error: error.message || 'Server Error'
  });
};

module.exports = { errorHandler };
