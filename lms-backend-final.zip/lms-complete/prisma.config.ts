// Updated prisma.config.ts
// FIXED: Added directUrl — required for Prisma migrations on Supabase
// FIXED: Removed deprecated package.json#prisma seed (use this file instead)
import "dotenv/config";
import { defineConfig } from "prisma/config";

export default defineConfig({
  schema: "prisma/schema.prisma",
  migrations: {
    path: "prisma/migrations",
  },
  seed: "node prisma/seed.js",
  datasource: {
    // url       → Pooler URL (Transaction mode, port 6543) — used at runtime
    // directUrl → Pooler URL (Session mode, port 5432)    — used by migrations
    //
    // WHY Session Mode for directUrl?
    // Direct connection (db.xxx.supabase.co:5432) is often blocked by ISPs/networks.
    // Session Mode pooler (aws-0-region.pooler.supabase.com:5432) supports DDL
    // commands needed for migrations AND is accessible from any network.
    url: process.env["DATABASE_URL"],
    directUrl: process.env["DIRECT_URL"],
  },
});
