-- ============================================================
-- Migration: Schema Improvements
-- Safe & non-destructive — no existing data is deleted.
-- ============================================================

-- STEP 1: Create UserStatus enum
DO $$ BEGIN
  CREATE TYPE "UserStatus" AS ENUM ('pending', 'approved', 'rejected', 'suspended');
EXCEPTION WHEN duplicate_object THEN NULL;
END $$;

-- STEP 2: Create CourseStatus enum
DO $$ BEGIN
  CREATE TYPE "CourseStatus" AS ENUM ('pending', 'approved', 'rejected');
EXCEPTION WHEN duplicate_object THEN NULL;
END $$;

-- STEP 3: Add bio and avatar to User if not present
ALTER TABLE "User" ADD COLUMN IF NOT EXISTS "bio"    TEXT;
ALTER TABLE "User" ADD COLUMN IF NOT EXISTS "avatar" TEXT;

-- STEP 4: Migrate User.status TEXT → UserStatus enum
UPDATE "User" SET "status" = 'pending'
WHERE "status" NOT IN ('pending', 'approved', 'rejected', 'suspended');

DO $$ BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'User' AND column_name = 'status' AND data_type = 'text'
  ) THEN
    ALTER TABLE "User" ALTER COLUMN "status" TYPE "UserStatus" USING "status"::"UserStatus";
    ALTER TABLE "User" ALTER COLUMN "status" SET DEFAULT 'pending'::"UserStatus";
  END IF;
END $$;

-- STEP 5: Migrate Course.status TEXT → CourseStatus enum
UPDATE "Course" SET "status" = 'pending'
WHERE "status" NOT IN ('pending', 'approved', 'rejected');

DO $$ BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'Course' AND column_name = 'status' AND data_type = 'text'
  ) THEN
    ALTER TABLE "Course" ALTER COLUMN "status" TYPE "CourseStatus" USING "status"::"CourseStatus";
    ALTER TABLE "Course" ALTER COLUMN "status" SET DEFAULT 'pending'::"CourseStatus";
  END IF;
END $$;

-- STEP 6: Add Course.slug column and auto-generate slugs
ALTER TABLE "Course" ADD COLUMN IF NOT EXISTS "slug" TEXT;

UPDATE "Course"
SET "slug" = LOWER(REGEXP_REPLACE(REGEXP_REPLACE(TRIM("title"), '[^a-zA-Z0-9\s]', '', 'g'), '\s+', '-', 'g'))
WHERE "slug" IS NULL OR "slug" = '';

UPDATE "Course" c1
SET "slug" = CONCAT(c1."slug", '-', SUBSTR(c1."id", 1, 6))
WHERE EXISTS (SELECT 1 FROM "Course" c2 WHERE c2."slug" = c1."slug" AND c2."id" < c1."id");

ALTER TABLE "Course" ALTER COLUMN "slug" SET NOT NULL;

DO $$ BEGIN
  ALTER TABLE "Course" ADD CONSTRAINT "Course_slug_key" UNIQUE ("slug");
EXCEPTION WHEN duplicate_object THEN NULL;
END $$;

-- STEP 7: Change Course.price Float → Integer
DO $$ BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'Course' AND column_name = 'price'
      AND data_type IN ('double precision', 'real', 'numeric')
  ) THEN
    ALTER TABLE "Course" ALTER COLUMN "price" TYPE INTEGER USING ROUND("price")::INTEGER;
    ALTER TABLE "Course" ALTER COLUMN "price" SET DEFAULT 0;
  END IF;
END $$;

-- STEP 8: Change Course instructor onDelete CASCADE → RESTRICT
ALTER TABLE "Course" DROP CONSTRAINT IF EXISTS "Course_instructorId_fkey";
ALTER TABLE "Course" ADD CONSTRAINT "Course_instructorId_fkey"
  FOREIGN KEY ("instructorId") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- STEP 9: Unique lesson order per course
DO $$ BEGIN
  ALTER TABLE "Lesson" ADD CONSTRAINT "Lesson_courseId_order_key" UNIQUE ("courseId", "order");
EXCEPTION WHEN duplicate_object THEN NULL;
END $$;

-- STEP 10: Performance indexes
CREATE INDEX IF NOT EXISTS "User_role_idx"           ON "User"("role");
CREATE INDEX IF NOT EXISTS "User_status_idx"         ON "User"("status");
CREATE INDEX IF NOT EXISTS "Course_instructorId_idx" ON "Course"("instructorId");
CREATE INDEX IF NOT EXISTS "Course_category_idx"     ON "Course"("category");
CREATE INDEX IF NOT EXISTS "Course_status_idx"       ON "Course"("status");
CREATE INDEX IF NOT EXISTS "Lesson_courseId_idx"     ON "Lesson"("courseId");
CREATE INDEX IF NOT EXISTS "Lesson_order_idx"        ON "Lesson"("order");
CREATE INDEX IF NOT EXISTS "Enrollment_userId_idx"   ON "Enrollment"("userId");
CREATE INDEX IF NOT EXISTS "Enrollment_courseId_idx" ON "Enrollment"("courseId");
CREATE INDEX IF NOT EXISTS "Enrollment_status_idx"   ON "Enrollment"("status");
