const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const compression = require('compression');
const pinoHttp = require('pino-http');
const logger = require('./utils/logger');
const { errorHandler } = require('./middlewares/error.middleware');
const setupSwagger = require('./docs/swagger');
const { RedisStore } = require('rate-limit-redis');
const redisClient = require('./services/redis.service');
const { prisma, checkDBHealth } = require('./config/db');

const app = express();

setupSwagger(app);
app.use(compression());
app.use(pinoHttp({ logger }));
app.use(helmet());
app.use(helmet.crossOriginResourcePolicy({ policy: "cross-origin" }));

const limiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 100,
  message: { success: false, error: 'Too many requests from this IP, please try again after 15 minutes' },
  standardHeaders: true,
  legacyHeaders: false,
  passOnStoreError: true,
  // store: new RedisStore({
  //   sendCommand: (...args) => redisClient.call(...args),
  // }),
});
app.use('/api', limiter);

const allowedOrigins = [
  'http://localhost:3000',
  'http://localhost:3001',
  'http://localhost:8080',
  'http://localhost:8081',
  'http://localhost:8082',
  'http://localhost:5173',
  'http://localhost:5174',
  process.env.CLIENT_URL,
].filter(Boolean);

app.use(cors({
  origin: function (origin, callback) {
    if (!origin || allowedOrigins.includes(origin)) {
      callback(null, true);
    } else {
      callback(null, true);
    }
  },
  credentials: true
}));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

const path = require('path');
app.use('/uploads', express.static(path.join(__dirname, '../uploads')));

// Routes
const authRoutesV1       = require('./routes/v1/auth.routes');
const courseRoutesV1     = require('./routes/v1/courses.routes');
const enrollmentRoutesV1 = require('./routes/v1/enrollment.routes');
const userRoutesV1       = require('./routes/v1/users.routes');
const adminRoutesV1      = require('./routes/v1/admin.routes');
const profileRoutesV1    = require('./routes/v1/profile.routes');
const uploadRoutesV1     = require('./routes/v1/upload.routes');

app.use('/api/v1/auth',        authRoutesV1);
app.use('/api/v1/courses',     courseRoutesV1);
app.use('/api/v1/enrollments', enrollmentRoutesV1);
app.use('/api/v1/users',       userRoutesV1);
app.use('/api/v1/admin',       adminRoutesV1);
app.use('/api/v1/profile',     profileRoutesV1);
app.use('/api/v1/upload',      uploadRoutesV1);

// Backward compatibility aliases
app.use('/api/auth',        authRoutesV1);
app.use('/api/courses',     courseRoutesV1);
app.use('/api/enrollments', enrollmentRoutesV1);
app.use('/api/users',       userRoutesV1);
app.use('/api/admin',       adminRoutesV1);
app.use('/api/profile',     profileRoutesV1);
app.use('/api/upload',      uploadRoutesV1);

app.get('/', (req, res) => {
  res.json({ message: 'Welcome to LMS Backend API' });
});

// UPDATED: Health check now uses checkDBHealth() for latency info
app.get('/health', async (req, res) => {
  try {
    const db = await checkDBHealth();
    if (db.status === 'ok') {
      res.status(200).json({
        status: 'ok',
        db: 'ok',
        dbLatencyMs: db.latencyMs,
        redis: 'ok',
        timestamp: new Date().toISOString(),
      });
    } else {
      res.status(503).json({
        status: 'error',
        db: 'error',
        dbError: db.message,
        timestamp: new Date().toISOString(),
      });
    }
  } catch (error) {
    logger.error({ err: error }, 'Health check failed');
    res.status(503).json({ status: 'error', details: error.message });
  }
});

app.use(errorHandler);

module.exports = app;
