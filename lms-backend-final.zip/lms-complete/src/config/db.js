require('dotenv').config();
const { PrismaClient } = require('@prisma/client');
const { PrismaPg } = require('@prisma/adapter-pg');
const logger = require('../utils/logger');

// ── Validate required env variables on startup ────────────
const validateEnv = () => {
  const required = ['DATABASE_URL', 'JWT_SECRET'];
  const missing = required.filter((key) => !process.env[key]);

  if (missing.length > 0) {
    logger.error(
      `Missing required environment variables: ${missing.join(', ')}. ` +
      `Copy .env.example to .env and fill in the values.`
    );
    process.exit(1);
  }

  const dbUrl = process.env.DATABASE_URL;
  if (!dbUrl.startsWith('postgresql://') && !dbUrl.startsWith('postgres://')) {
    logger.error('DATABASE_URL must start with postgresql:// or postgres://');
    process.exit(1);
  }

  if (!process.env.DIRECT_URL) {
    logger.warn(
      'DIRECT_URL is not set. Prisma migrations may fail on Supabase. ' +
      'Set DIRECT_URL to your Supabase Session Mode pooler URL.'
    );
  }

  if (
    !process.env.JWT_SECRET ||
    process.env.JWT_SECRET === 'your_super_secret_jwt_key_here' ||
    process.env.JWT_SECRET.length < 32
  ) {
    logger.warn('JWT_SECRET is weak or default. Use a strong secret in production.');
  }
};

validateEnv();

// ── Prisma 7: connection is passed via adapter to PrismaClient ──
// url/directUrl are NO LONGER in schema.prisma — they live in prisma.config.ts
// For the runtime client, we pass the connection string via PrismaPg adapter
const adapter = new PrismaPg({ connectionString: process.env.DATABASE_URL });

const prisma = new PrismaClient({
  adapter,
  log: process.env.NODE_ENV === 'production' ? ['warn', 'error'] : ['warn', 'error'],
});

// ── Connect with helpful error messages ───────────────────
const connectDB = async () => {
  try {
    await prisma.$connect();
    await prisma.$queryRaw`SELECT 1`;
    logger.info('PostgreSQL Connected via Prisma');
  } catch (error) {
    const msg = error.message || '';

    if (msg.includes('ECONNREFUSED')) {
      logger.error('Connection refused. Check DATABASE_URL host and port.');
    } else if (msg.includes('password authentication failed')) {
      logger.error('Auth failed. Check username/password in DATABASE_URL.');
    } else if (msg.includes('does not exist')) {
      logger.error('Database does not exist. Check database name in DATABASE_URL.');
    } else if (msg.toLowerCase().includes('ssl') || msg.includes('certificate')) {
      logger.error('SSL error. Use Supabase Pooler URL (port 6543) for DATABASE_URL.');
    } else if (msg.includes('prepared statement') || msg.includes('pgbouncer')) {
      logger.error('pgBouncer conflict. Add ?pgbouncer=true&connection_limit=1 to DATABASE_URL.');
    } else if (msg.includes('ETIMEDOUT') || msg.includes('timeout')) {
      logger.error('Connection timed out. Check network and firewall rules.');
    } else {
      logger.error({ err: error }, 'Database connection failed');
    }

    process.exit(1);
  }
};

// ── Health check helper for GET /health ──────────────────
const checkDBHealth = async () => {
  const start = Date.now();
  try {
    await prisma.$queryRaw`SELECT 1`;
    return { status: 'ok', latencyMs: Date.now() - start };
  } catch (error) {
    return { status: 'error', latencyMs: Date.now() - start, message: error.message };
  }
};

module.exports = { connectDB, prisma, checkDBHealth };
